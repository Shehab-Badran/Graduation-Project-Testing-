package Automation_Project.Automation_Graduation_Project;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class CategoryPage {
    WebDriver driver;
    WebDriverWait wait;

    public CategoryPage(WebDriver driver) {
        this.driver = driver;
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    By menCategoryToggle = By.xpath("//a[contains(text(),'Men')]");
    By menTshirtsLink = By.xpath("//a[contains(text(),'Tshirts')]");
    By categoryPanel = By.className("category-products");

    public void clickMenTshirtsCategory() {
        driver.get("https://automationexercise.com/products");

        // Wait for category panel
        wait.until(ExpectedConditions.visibilityOfElementLocated(categoryPanel));

        // Scroll and click "Men"
        WebElement menCategory = wait.until(ExpectedConditions.presenceOfElementLocated(menCategoryToggle));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", menCategory);
        wait.until(ExpectedConditions.elementToBeClickable(menCategory)).click();

        // Scroll and click "Tshirts"
        WebElement tshirts = wait.until(ExpectedConditions.presenceOfElementLocated(menTshirtsLink));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", tshirts);
        wait.until(ExpectedConditions.elementToBeClickable(tshirts)).click();
    }
}

package Automation_Project.Automation_Graduation_Project;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class CartPage {
    WebDriver driver;

    public CartPage(WebDriver driver) {
        this.driver = driver;
    }

    By productsLink = By.xpath("//a[@href='/products']");
    By searchField = By.id("search_product");
    By searchButton = By.id("submit_search");
    By firstAddToCartBtn = By.xpath("(//a[contains(text(),'Add to cart')])[1]");
    By continueShoppingBtn = By.xpath("//button[text()='Continue Shopping']");
    By cartLink = By.xpath("//a[@href='/view_cart']");
    By removeBtn = By.className("cart_quantity_delete");
    By productRowSelector = By.xpath("//tr[starts-with(@id, 'product-')]");
    By productBlock = By.cssSelector(".productinfo.text-center");

    public void goToProductsPage() {
        driver.findElement(productsLink).click();
    }

    public void searchProduct(String keyword) {
        driver.findElement(searchField).clear();
        driver.findElement(searchField).sendKeys(keyword);
        driver.findElement(searchButton).click();
    }

    public void addFirstProductToCart() {
        WebElement addToCartBtn = driver.findElement(firstAddToCartBtn);
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", addToCartBtn);
    }

    public void continueShopping() {
        driver.findElement(continueShoppingBtn).click();
    }

    public void openCart() {
        driver.findElement(cartLink).click();
    }

    public void removeProductFromCart() {
        WebElement remove = driver.findElement(removeBtn);
        remove.click();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.stalenessOf(remove)); // wait until item disappears
    }

    public boolean isCartEmpty() {
        try {
            List<WebElement> remainingItems = driver.findElements(productRowSelector);
            System.out.println("Remaining cart items: " + remainingItems.size());
            return remainingItems.size() == 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean isSearchResultEmpty() {
        try {
            Thread.sleep(1500); // wait for products to load
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        List<WebElement> results = driver.findElements(productBlock);
        int count = results.size();
        System.out.println("Search result product count: " + count);
        return count == 0;
    }
}

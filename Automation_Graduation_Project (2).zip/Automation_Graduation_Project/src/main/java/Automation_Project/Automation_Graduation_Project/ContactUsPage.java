package Automation_Project.Automation_Graduation_Project;

import java.io.File;
import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class ContactUsPage extends PageBase {

    public ContactUsPage(WebDriver driver) {
        super(driver);
    }

    @FindBy(xpath = "//a[contains(text(),'Contact us')]")
    WebElement contactUsLink;

    @FindBy(name = "name")
    WebElement nameInput;

    @FindBy(name = "email")
    WebElement emailInput;

    @FindBy(name = "subject")
    WebElement subjectInput;

    @FindBy(name = "message")
    WebElement messageTextarea;

    @FindBy(name = "upload_file")
    WebElement uploadFileInput;

    @FindBy(name = "submit")
    WebElement submitButton;

    @FindBy(xpath = "//div[contains(@class,'status alert alert-success')]")
    public WebElement successMessage;

    @FindBy(xpath = "//a[contains(text(),'Home')]")
    WebElement homeButton;

    public void openContactUsForm() {
        contactUsLink.click();
    }

    public void fillContactForm(String name, String email, String subject, String message, String filePath) {
        nameInput.sendKeys(name);
        emailInput.sendKeys(email);
        subjectInput.sendKeys(subject);
        messageTextarea.sendKeys(message);

        if (filePath != null && !filePath.isEmpty()) {
            uploadFileInput.sendKeys(new File(filePath).getAbsolutePath());
        }

        // Scroll to submit button
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", submitButton);

        // Wait until clickable
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(submitButton));

        // Click and handle alert
        submitButton.click();
        wait.until(ExpectedConditions.alertIsPresent());

        Alert alert = driver.switchTo().alert();
        alert.accept(); // Click OK on the alert
    }

    public void clickHomeButton() {
        homeButton.click();
    }
}

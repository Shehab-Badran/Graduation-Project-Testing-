package Automation_Project.Automation_Graduation_Project;

import java.util.List;
import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class RegisterPage extends PageBase {

    public RegisterPage(WebDriver driver) {
        super(driver);
    }

    // --- Signup fields ---
    @FindBy(name = "name")
    WebElement nameInput;

    @FindBy(name = "email")
    List<WebElement> emailInputs;

    @FindBy(xpath = "//*[@id=\"form\"]/div/div/div[3]/div/form/button")
    WebElement signUpButton;

    // --- Account Info ---
    @FindBy(id = "id_gender1")
    WebElement maleGender;

    @FindBy(id = "password")
    WebElement passwordInput;

    @FindBy(id = "days")
    WebElement daySelect;

    @FindBy(id = "months")
    WebElement monthSelect;

    @FindBy(id = "years")
    WebElement yearSelect;

    @FindBy(id = "first_name")
    WebElement firstName;

    @FindBy(id = "last_name")
    WebElement lastName;

    @FindBy(id = "address1")
    WebElement address1;

    @FindBy(id = "state")
    WebElement state;

    @FindBy(id = "city")
    WebElement city;

    @FindBy(id = "zipcode")
    WebElement zip;

    @FindBy(id = "mobile_number")
    WebElement mobile;

    @FindBy(xpath = "//button[contains(text(),'Create Account')]")
    WebElement createAccountBtn;

    // --- Final messages ---
    @FindBy(xpath = "//b[text()='Account Created!']")
    public WebElement successMessage;

    @FindBy(xpath = "//a[@class='btn btn-primary']")
    WebElement continueBtn;

    @FindBy(xpath = "//a[contains(text(),'Logged in as')]")
    public WebElement loggedInLink;

    @FindBy(xpath = "//p[contains(text(),'Email Address already exist!')]")
    public WebElement failedMessage;

    @FindBy(xpath = "//h2[text()='New User Signup!']")
    public WebElement newUserMessage;
    
    @FindBy(xpath = "//a[@href='/delete_account']")
    WebElement deleteAccountLink;

    @FindBy(xpath = "//b[text()='Account Deleted!']")
    public WebElement deleteMessage;


    // --- Methods ---
    public void startRegistration(String name, String email) {
        nameInput.sendKeys(name);
        emailInputs.get(1).sendKeys(email);
        signUpButton.click();
    }

    public void fillAccountInfo(String password) {
        maleGender.click();
        passwordInput.sendKeys(password);
        new Select(daySelect).selectByValue("10");
        new Select(monthSelect).selectByValue("5");
        new Select(yearSelect).selectByVisibleText("2000");

        firstName.sendKeys("Shehab");
        lastName.sendKeys("Badran");
        address1.sendKeys("Zayed");
        state.sendKeys("Cairo");
        city.sendKeys("Cairo");
        zip.sendKeys("12345");
        mobile.sendKeys("01012345678");

        // Fix intercepted click
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", createAccountBtn);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(createAccountBtn));
        createAccountBtn.click();
    }

    public void continueAfterAccountCreated() {
        continueBtn.click();
    }
    
    public void deleteAccount() {
        deleteAccountLink.click();
    }


}

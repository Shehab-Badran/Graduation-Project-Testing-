package Automation_Project.Automation_Graduation_Project;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SearchPage extends PageBase {

    public SearchPage(WebDriver driver) {
        super(driver);
    }

    @FindBy(xpath = "//a[@href='/products']")
    WebElement productsNavBtn;

    @FindBy(id = "search_product")
    WebElement searchInput;

    @FindBy(id = "submit_search")
    WebElement searchButton;

    @FindBy(xpath = "//h2[contains(text(),'Searched Products')]")
    public WebElement searchedProductsTitle;

    @FindBy(css = ".features_items .product-image-wrapper")
    public List<WebElement> resultCards;

    public void openProductsPage() {
        productsNavBtn.click();
    }

    public void searchFor(String keyword) {
        searchInput.clear();
        searchInput.sendKeys(keyword);
        searchButton.click();
    }

    public boolean hasSearchResults() {
        return !resultCards.isEmpty();
    }
}

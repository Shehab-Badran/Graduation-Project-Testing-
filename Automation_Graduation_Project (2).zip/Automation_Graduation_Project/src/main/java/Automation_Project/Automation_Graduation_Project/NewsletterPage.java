package Automation_Project.Automation_Graduation_Project;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class NewsletterPage {
    WebDriver driver;

    By emailInput = By.id("susbscribe_email");
    By subscribeButton = By.id("subscribe");
    By successAlert = By.id("success-subscribe");

    public NewsletterPage(WebDriver driver) {
        this.driver = driver;
    }

    public void enterEmail(String email) {
        driver.findElement(emailInput).clear();
        driver.findElement(emailInput).sendKeys(email);
    }

    public void clickSubscribe() {
        driver.findElement(subscribeButton).click();
    }

    public String getSubscriptionAlertText() {
        return driver.findElement(successAlert).getText();
    }
}

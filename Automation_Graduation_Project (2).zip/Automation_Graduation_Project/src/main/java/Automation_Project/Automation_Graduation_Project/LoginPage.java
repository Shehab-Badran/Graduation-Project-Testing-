package Automation_Project.Automation_Graduation_Project;

import java.util.List;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage extends PageBase {

    public LoginPage(WebDriver driver) {
        super(driver);
    }

    @FindBy(name = "email")
    List<WebElement> emailInputs;

    @FindBy(name = "password")
    WebElement passwordInput;

    @FindBy(xpath = "//button[contains(text(),'Login')]")
    WebElement loginBtn;

    @FindBy(xpath = "//p[contains(text(),'Your email or password is incorrect!')]")
    public WebElement loginErrorMsg;

    @FindBy(xpath = "//a[contains(text(),'Logout')]")
    WebElement logoutLink;

    public void login(String email, String password) {
        emailInputs.get(0).sendKeys(email);
        passwordInput.sendKeys(password);
        loginBtn.click();
    }

    public void logout() {
        logoutLink.click();
    }
}

package Automation_Project.Automation_Graduation_Project;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage extends PageBase {

    public HomePage(WebDriver driver) {
        super(driver);
    }

    @FindBy(xpath = "//a[contains(text(),'Signup / Login')]")
    WebElement signupLoginLink;

    @FindBy(xpath = "//a[contains(text(),'Delete Account')]")
    WebElement deleteAccountLink;

    @FindBy(xpath = "//a[contains(text(),'Logout')]")
    public WebElement logoutLink;

    @FindBy(xpath = "//a[contains(text(),'Home')]")
    public WebElement homeLink;

    @FindBy(xpath = "//a[contains(text(),'Logged in as')]")
    public WebElement loggedInLink;
    

    public void openSignupLoginPage() {
        signupLoginLink.click();
    }

    public void deleteAccount() {
        deleteAccountLink.click();
    }

   

    public boolean isHomeLoaded() {
        return homeLink.getCssValue("color").equals("rgba(255, 165, 0, 1)");
    }
}

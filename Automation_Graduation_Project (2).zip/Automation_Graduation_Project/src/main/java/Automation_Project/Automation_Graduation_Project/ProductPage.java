package Automation_Project.Automation_Graduation_Project;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ProductPage extends PageBase {

    public ProductPage(WebDriver driver) {
        super(driver);
    }

    @FindBy(xpath = "//a[@href='/products']")
    WebElement productsNavBtn;

    @FindBy(xpath = "//h2[contains(text(),'All Products')]")
    public WebElement allProductsHeader;

    @FindBy(css = ".features_items .product-image-wrapper")
    public WebElement productCard;

    @FindBy(xpath = "//a[contains(text(),'View Product')]")
    WebElement viewProductBtn;

    @FindBy(xpath = "//div[@class='product-information']/h2")
    public WebElement productName;

    @FindBy(xpath = "//div[@class='product-information']/p[1]")
    public WebElement category;

    @FindBy(xpath = "//div[@class='product-information']/span/span")
    public WebElement price;

    @FindBy(xpath = "//div[@class='product-information']/p[2]")
    public WebElement availability;

    @FindBy(xpath = "//div[@class='product-information']/p[3]")
    public WebElement condition;

    @FindBy(xpath = "//div[@class='product-information']/p[4]")
    public WebElement brand;

    public void goToProductsPage() {
        productsNavBtn.click();
    }

    public void viewFirstProduct() {
        viewProductBtn.click();
    }
}

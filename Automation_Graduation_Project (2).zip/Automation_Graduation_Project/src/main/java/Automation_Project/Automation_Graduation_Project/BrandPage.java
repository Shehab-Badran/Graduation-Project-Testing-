package Automation_Project.Automation_Graduation_Project;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import java.util.List;

public class BrandPage {
    WebDriver driver;

    public BrandPage(WebDriver driver) {
        this.driver = driver;
    }

    By brandList = By.cssSelector(".brands-name ul li a");

    public void clickOnBrand(String brandName) {
        List<WebElement> brands = driver.findElements(brandList);
        for (WebElement brand : brands) {
            if (brand.getText().trim().equalsIgnoreCase(brandName)) {
                brand.click();
                break;
            }
        }
    }

    public boolean isBrandProductDisplayed(String brandName) {
        return driver.getPageSource().toLowerCase().contains(brandName.toLowerCase());
    }
}

package Automation_Project.Automation_Graduation_Project;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CheckoutPage {
    WebDriver driver;

    public CheckoutPage(WebDriver driver) {
        this.driver = driver;
    }

    By cartButton = By.xpath("//a[@href='/view_cart']");
    By proceedToCheckoutBtn = By.xpath("//a[contains(text(),'Proceed To Checkout')]");
    By addressInfo = By.xpath("//ul[@id='address_delivery']");
    By placeOrderBtn = By.xpath("//a[text()='Place Order']");
    By nameOnCard = By.name("name_on_card");
    By cardNumber = By.name("card_number");
    By cvc = By.name("cvc");
    By expiryMonth = By.name("expiry_month");
    By expiryYear = By.name("expiry_year");
    By payAndConfirmOrderBtn = By.id("submit");
    By orderSuccessMessage = By.xpath("//*[contains(text(),'Your order has been placed successfully!')]");
    By downloadInvoiceBtn = By.xpath("//a[text()='Download Invoice']");

    public void goToCart() {
        driver.findElement(cartButton).click();
    }

    public void proceedToCheckout() {
        driver.findElement(proceedToCheckoutBtn).click();
    }

    public boolean isAddressDisplayed() {
        return driver.findElement(addressInfo).isDisplayed();
    }

    public void placeOrder() {
        WebElement placeOrderBtn = driver.findElement(By.xpath("//a[text()='Place Order']"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", placeOrderBtn);
    }

    public void fillPaymentDetails(String name, String number, String cvcCode, String month, String year) {
        driver.findElement(nameOnCard).sendKeys(name);
        driver.findElement(cardNumber).sendKeys(number);
        driver.findElement(cvc).sendKeys(cvcCode);
        driver.findElement(expiryMonth).sendKeys(month);
        driver.findElement(expiryYear).sendKeys(year);
    }

    public void confirmOrder() {
        driver.findElement(payAndConfirmOrderBtn).click();
    }

    public boolean isOrderSuccessMessageDisplayed() {
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement message = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector("#form > div > div > div > p")
            ));
            String actualText = message.getText().trim();
            System.out.println("Success message: " + actualText);
            return actualText.contains("Congratulations! Your order has been confirmed!");
        } catch (Exception e) {
            System.out.println("Success message not found!");
            return false;
        }
    }



    public void downloadInvoice() {
        driver.findElement(downloadInvoiceBtn).click();
    }
}

package Automation_Project.Automation_Graduation_Project;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.Assert;
import org.openqa.selenium.By;

public class RegisterTests_happyScenario extends TestBase {

    RegisterPage registerPage;

    @BeforeMethod
    public void initPages() {
        registerPage = new RegisterPage(driver);
    }

    @Test
    public void testRegisterWithValidData() throws InterruptedException {
        // Step 1: Open signup/login
        driver.findElement(By.xpath("//a[contains(text(),'Signup / Login')]")).click();
        Thread.sleep(1000);

        // Step 2: Fill name + email
        String name = "Shehab Badran";
        String email = "shehab" + System.currentTimeMillis() + "@gmail.com";
        registerPage.startRegistration(name, email);
        Thread.sleep(1000);

        // Step 3: Fill full account details
        registerPage.fillAccountInfo("12345678");
        Thread.sleep(1000);

        // Step 4: Assert success message
        Assert.assertTrue(registerPage.successMessage.isDisplayed(), "Account created!");

        // Step 5: Continue and check logged in
        registerPage.continueAfterAccountCreated();
        Thread.sleep(1000);
        Assert.assertTrue(registerPage.loggedInLink.getText().contains("Shehab"));

        // Step 6: Delete the account and verify
        registerPage.deleteAccount();
        Assert.assertTrue(registerPage.deleteMessage.isDisplayed(), "Account deletion sucsess.");
    }
}

package Automation_Project.Automation_Graduation_Project;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.Assert;

public class SearchTests_happyScenario extends TestBase {

    SearchPage searchPage;

    @BeforeMethod
    public void setup() {
        searchPage = new SearchPage(driver);
    }

    @Test
    public void testSearchWithValidKeyword() throws InterruptedException {
        // Step 1: Navigate to Products page
        searchPage.openProductsPage();
        Thread.sleep(1000);

        // Step 2: Perform valid search
        searchPage.searchFor("Jeans");
        Thread.sleep(1000);

        // Step 3: Validate search results section is visible
        Assert.assertTrue(searchPage.searchedProductsTitle.isDisplayed(), "'Searched Products' title  visible");

        // Step 4: Validate that product cards are shown
        Assert.assertTrue(searchPage.hasSearchResults(), " products are found for valid search keyword.");
    }
}

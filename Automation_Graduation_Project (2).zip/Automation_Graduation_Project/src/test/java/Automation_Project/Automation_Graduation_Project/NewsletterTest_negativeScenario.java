package Automation_Project.Automation_Graduation_Project;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.Assert;
import org.openqa.selenium.JavascriptExecutor;

public class NewsletterTest_negativeScenario extends TestBase {

    NewsletterPage newsletterPage;

    @BeforeMethod
    public void setup() {
        newsletterPage = new NewsletterPage(driver);
    }

    @Test
    public void testSubscriptionWithInvalidEmail() throws InterruptedException {
        // Scroll to footer
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
        Thread.sleep(1000);

        // Use invalid email
        newsletterPage.enterEmail("invalidEmail");
        newsletterPage.clickSubscribe();
        Thread.sleep(1000);

        // Grab the alert and validate it's not success
        String alertText = newsletterPage.getSubscriptionAlertText().trim().toLowerCase();
        System.out.println("Newsletter alert message: " + alertText);

        // Expect it NOT to be successful
        Assert.assertFalse(alertText.contains(" Not successfully subscribed"),
            "Subscription should not succeed with an invalid email.");
    }
}

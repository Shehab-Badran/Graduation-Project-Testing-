package Automation_Project.Automation_Graduation_Project;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.Assert;

public class BrandTests_happyScenario extends TestBase {

    BrandPage brandPage;

    @BeforeMethod
    public void setupPage() {
        brandPage = new BrandPage(driver);
    }

    @Test
    public void testViewPoloBrandProducts() {
        brandPage.clickOnBrand("Polo");
        Assert.assertTrue(brandPage.isBrandProductDisplayed("Polo"));
    }
}

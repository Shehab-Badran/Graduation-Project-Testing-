package Automation_Project.Automation_Graduation_Project;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.Assert;

public class Login_NegativeScenario extends TestBase {

    LoginPage loginPage;
    HomePage homePage;

    @BeforeMethod
    public void initPages() {
        loginPage = new LoginPage(driver);
        homePage = new HomePage(driver);
    }

    @Test(priority = 1)
    public void testLoginWithWrongPassword() throws InterruptedException {
        homePage.openSignupLoginPage();
        Thread.sleep(1000);

        loginPage.login("shehabbadran07@gmail.com", "wrongpassword");
        Thread.sleep(1000);

        Assert.assertTrue(loginPage.loginErrorMsg.isDisplayed(), "Error message shown");
    }

    @Test(priority = 2)
    public void testLoginWithInvalidEmail() throws InterruptedException {
        homePage.openSignupLoginPage();
        Thread.sleep(1000);

        loginPage.login("invalidemail@gmail.com", "12345678");
        Thread.sleep(1000);

        Assert.assertTrue(loginPage.loginErrorMsg.isDisplayed(), "Error message shown");
    }
}

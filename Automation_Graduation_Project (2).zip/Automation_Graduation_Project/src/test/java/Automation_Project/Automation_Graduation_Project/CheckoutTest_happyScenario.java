package Automation_Project.Automation_Graduation_Project;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.Assert;

public class CheckoutTest_happyScenario extends TestBase {

    LoginPage loginPage;
    HomePage homePage;
    CartPage cartPage;
    CheckoutPage checkoutPage;

    @BeforeMethod
    public void setupPages() {
        loginPage = new LoginPage(driver);
        homePage = new HomePage(driver);
        cartPage = new CartPage(driver);
        checkoutPage = new CheckoutPage(driver);
    }

    @Test
    public void testSuccessfulCheckoutProcess() throws InterruptedException {
        // Step 1: Login
        homePage.openSignupLoginPage();
        loginPage.login("Shehabbadran07@gmail.com", "Shehab2004");
        Thread.sleep(1500);
        Assert.assertTrue(homePage.logoutLink.isDisplayed(), "Login Success");

        // Step 2: Add product to cart
        cartPage.goToProductsPage();
        cartPage.searchProduct("top");
        Thread.sleep(1000);
        cartPage.addFirstProductToCart();
        Thread.sleep(1000);
        cartPage.continueShopping();

        // Step 3: Proceed to checkout
        checkoutPage.goToCart();
        Thread.sleep(1000);
        checkoutPage.proceedToCheckout();
        Thread.sleep(1000);

        // Step 4: Validate address and place order
        Assert.assertTrue(checkoutPage.isAddressDisplayed(), "Address displayed");
        checkoutPage.placeOrder();

        // Step 5: Enter payment info and confirm
        checkoutPage.fillPaymentDetails("Shehab Badran", "4242424242424242", "123", "12", "2026");
        checkoutPage.confirmOrder();
        Thread.sleep(2000);

        // Step 6: Verify order success
        Assert.assertTrue(checkoutPage.isOrderSuccessMessageDisplayed(), "Order was successful");

        // Step 7: Download invoice (optional)
        checkoutPage.downloadInvoice();
    }
}

package Automation_Project.Automation_Graduation_Project;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.Assert;

public class CartTest_happyScenario extends TestBase {

    CartPage cartPage;

    @BeforeMethod
    public void setupPages() {
        cartPage = new CartPage(driver);
    }

    @Test(priority = 1)
    public void testAddAndRemoveProductSuccessfully() throws InterruptedException {
        cartPage.goToProductsPage();
        Thread.sleep(1000);

        cartPage.searchProduct("jeans");
        Thread.sleep(1000);

        cartPage.addFirstProductToCart();
        Thread.sleep(1000);

        cartPage.continueShopping();
        Thread.sleep(1000);

        cartPage.openCart();
        Thread.sleep(1000);

        cartPage.removeProductFromCart();
        Thread.sleep(1000);

        Assert.assertTrue(cartPage.isCartEmpty(), "Cart should be empty after removing the product");
    }
}

package Automation_Project.Automation_Graduation_Project;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

public class CategoryTests_negativeScenario extends TestBase {

    @Test(priority = 1)
    public void testNonExistentCategoryClick() {
        driver.get("https://automationexercise.com/products");
        try {
            WebElement fakeCategory = driver.findElement(By.xpath("//a[contains(text(),'FakeCategory')]"));
            fakeCategory.click();
            Assert.fail("Non-existent category should not be found.");
        } catch (org.openqa.selenium.NoSuchElementException e) {
            // Expected behavior
            Assert.assertTrue(true);
        }
    }

    @Test(priority = 2)
    public void testProductListNotShownWithoutCategoryClick() {
        // Navigate directly to the product listing page
        driver.get("https://automationexercise.com/products");

        // Check if product section is displayed
        WebElement productSection = driver.findElement(By.xpath("//div[@class='features_items']"));
        Assert.assertTrue(productSection.isDisplayed(), "Product section should be visible by default");

        // Verify that some products are shown
        int productCount = driver.findElements(By.className("product-image-wrapper")).size();
        Assert.assertTrue(productCount > 0, "Products should be listed by default even without category filter");
    }
}

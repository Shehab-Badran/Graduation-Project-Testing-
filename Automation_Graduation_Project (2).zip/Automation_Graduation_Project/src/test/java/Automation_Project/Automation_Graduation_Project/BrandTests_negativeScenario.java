package Automation_Project.Automation_Graduation_Project;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.Assert;
import org.openqa.selenium.NoSuchElementException;

public class BrandTests_negativeScenario extends TestBase {

    BrandPage brandPage;

    @BeforeMethod
    public void setupPage() {
        brandPage = new BrandPage(driver);
    }

    @Test
    public void testClickNonExistentBrand() {
        try {
            brandPage.clickOnBrand("NonExistentBrand123");
            boolean isDisplayed = brandPage.isBrandProductDisplayed("NonExistentBrand123");
            Assert.assertFalse(isDisplayed, "Non-existent brand should not display any products.");
        } catch (NoSuchElementException e) {
            // Expected if the brand doesn't exist in the list
            Assert.assertTrue(true);
        }
    }
}


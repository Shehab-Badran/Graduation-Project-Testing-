package Automation_Project.Automation_Graduation_Project;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.Assert;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class SearchTests_negativeScenario extends TestBase {

    SearchPage searchPage;

    @BeforeMethod
    public void setup() {
        searchPage = new SearchPage(driver);
    }

    @Test
    public void testSearchWithInvalidKeyword() throws InterruptedException {
        // Step 1: Go to Products page
        searchPage.openProductsPage();
        Thread.sleep(1000);

        // Step 2: Search for invalid term
        searchPage.searchFor("zzzzzzzz");
        Thread.sleep(1000);

        // Step 3: Assert "Searched Products" title is still visible
        Assert.assertTrue(searchPage.searchedProductsTitle.isDisplayed(), "'Searched Products'  not visible");

        // Step 4: Check if any product cards appear (should NOT)
        List<WebElement> results = driver.findElements(By.cssSelector(".features_items .product-image-wrapper"));
        Assert.assertTrue(results.isEmpty(), "No product results found for invalid search.");
    }
}

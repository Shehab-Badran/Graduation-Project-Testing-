package Automation_Project.Automation_Graduation_Project;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.Assert;

public class ContactUsTests extends TestBase {

    ContactUsPage contactPage;

    @BeforeMethod
    public void setup() {
        contactPage = new ContactUsPage(driver);
    }

    @Test
    public void testSubmitContactUsForm() throws InterruptedException {
        contactPage.openContactUsForm();
        Thread.sleep(1000);

        String filePath = System.getProperty("user.dir") + "/images/SS.png";
    

        contactPage.fillContactForm(
            "Shehab Badran",
            "shehab@example.com",
            "Bug Report",
            "Here's the screenshot you requested.",
            filePath
        );

        Thread.sleep(1000);
        Assert.assertTrue(contactPage.successMessage.isDisplayed(), "Success message shown");

        contactPage.clickHomeButton();
        Thread.sleep(1000);
        Assert.assertTrue(driver.getCurrentUrl().equals("https://automationexercise.com/"));
    }
}
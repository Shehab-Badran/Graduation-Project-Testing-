package Automation_Project.Automation_Graduation_Project;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.Assert;

public class CartTest_negativeScenario extends TestBase {

    CartPage cartPage;

    @BeforeMethod
    public void setupPages() {
        cartPage = new CartPage(driver);
    }

    @Test(priority = 1)
    public void testSearchForInvalidProduct() throws InterruptedException {
        cartPage.goToProductsPage();
        cartPage.searchProduct("KORA");

        Assert.assertTrue(cartPage.isSearchResultEmpty(), "No products should be found with invalid search term");
    }
}

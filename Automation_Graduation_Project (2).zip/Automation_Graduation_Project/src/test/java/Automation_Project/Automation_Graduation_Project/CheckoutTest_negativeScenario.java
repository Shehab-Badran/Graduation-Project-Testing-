package Automation_Project.Automation_Graduation_Project;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.Assert;

public class CheckoutTest_negativeScenario extends TestBase {

    LoginPage loginPage;
    HomePage homePage;
    CartPage cartPage;
    CheckoutPage checkoutPage;

    @BeforeMethod
    public void setupPages() {
        loginPage = new LoginPage(driver);
        homePage = new HomePage(driver);
        cartPage = new CartPage(driver);
        checkoutPage = new CheckoutPage(driver);
    }

    @Test
    public void testCheckoutWithoutCVC() throws InterruptedException {
        // Step 1: Login
        homePage.openSignupLoginPage();
        loginPage.login("Shehabbadran07@gmail.com", "Shehab2004");
        Thread.sleep(1500);
        Assert.assertTrue(homePage.logoutLink.isDisplayed(), "Login Success");

        // Step 2: Add product to cart
        cartPage.goToProductsPage();
        cartPage.searchProduct("top");
        Thread.sleep(1000);
        cartPage.addFirstProductToCart();
        Thread.sleep(1000);
        cartPage.continueShopping();

        // Step 3: Checkout
        checkoutPage.goToCart();
        Thread.sleep(1000);
        checkoutPage.proceedToCheckout();
        Thread.sleep(1000);
        Assert.assertTrue(checkoutPage.isAddressDisplayed(), "Address not displayed");
        checkoutPage.placeOrder();

        // Step 4: Fill payment info (except CVC)
        driver.findElement(checkoutPage.nameOnCard).sendKeys("Shehab");
        driver.findElement(checkoutPage.cardNumber).sendKeys("4242424242424242");
        // Do NOT fill the CVC
        driver.findElement(checkoutPage.expiryMonth).sendKeys("12");
        driver.findElement(checkoutPage.expiryYear).sendKeys("2026");

        // Step 5: Attempt to confirm order
        checkoutPage.confirmOrder();
        Thread.sleep(2000);

        // Step 6: Assert that order was NOT successful
        Assert.assertFalse(checkoutPage.isOrderSuccessMessageDisplayed(),
            "Order succeeded without CVC, which is invalid.");
    }
}

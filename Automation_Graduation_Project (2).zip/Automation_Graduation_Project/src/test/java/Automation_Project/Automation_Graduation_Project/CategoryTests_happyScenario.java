package Automation_Project.Automation_Graduation_Project;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

public class CategoryTests_happyScenario extends TestBase {

    CategoryPage categoryPage;

    @BeforeMethod
    public void setup() {
        categoryPage = new CategoryPage(driver);
    }

    @Test(priority = 1)
    public void testProductListShownWithCategoryClick() {
        // Navigate directly to the product listing page
        driver.get("https://automationexercise.com/products");

        // Check if product section is displayed
        WebElement productSection = driver.findElement(By.xpath("//div[@class='features_items']"));
        Assert.assertTrue(productSection.isDisplayed(), "Product section should be visible by default");

        // Verify that some products are shown
        int productCount = driver.findElements(By.className("product-image-wrapper")).size();
        Assert.assertTrue(productCount > 0, "Products should be listed by default even without category filter");
    }
}

package Automation_Project.Automation_Graduation_Project;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.Assert;

public class ProductTests_happyScenario extends TestBase {

    ProductPage productPage;

    @BeforeMethod
    public void setup() {
        productPage = new ProductPage(driver);
    }

    @Test
    public void testViewProductDetails_HappyScenario() throws InterruptedException {
        productPage.goToProductsPage();
        Thread.sleep(1000);

        Assert.assertTrue(productPage.allProductsHeader.isDisplayed(), "All Products page is  visible");

        productPage.viewFirstProduct();
        Thread.sleep(1000);

        Assert.assertTrue(productPage.productName.isDisplayed(), "Product name is  visible");
        Assert.assertTrue(productPage.category.isDisplayed(), "Product category is  visible");
        Assert.assertTrue(productPage.price.isDisplayed(), "Product price is  visible");
        Assert.assertTrue(productPage.availability.isDisplayed(), "Product availability is  visible");
        Assert.assertTrue(productPage.condition.isDisplayed(), "Product condition is  visible");
        Assert.assertTrue(productPage.brand.isDisplayed(), "Product brand is  visible");
    }
}

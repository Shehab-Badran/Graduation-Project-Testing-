package Automation_Project.Automation_Graduation_Project;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.Assert;
import org.openqa.selenium.By;

public class LoginTests_happyScenario extends TestBase {

    LoginPage loginPage;
    HomePage homePage;

    @BeforeMethod
    public void initPages() {
        loginPage = new LoginPage(driver);
        homePage = new HomePage(driver);
    }

    @Test
    public void testLoginWithValidCredentials() throws InterruptedException {
        homePage.openSignupLoginPage();
        Thread.sleep(1000);

        String email = "Shehabbadran07@gmail.com"; // use valid existing account
        String password = "Shehab2004";

        loginPage.login(email, password);
        Thread.sleep(1000);

        Assert.assertTrue(loginPage.logoutLink.isDisplayed(), "Login Sucssess");
        Assert.assertTrue(homePage.loggedInLink.getText().toLowerCase().contains("shehab"));

        // Optional logout at the end
        loginPage.logout();
        Thread.sleep(1000);
        Assert.assertTrue(driver.findElement(By.xpath("//button[contains(text(),'Login')]")).isDisplayed());
    }
}

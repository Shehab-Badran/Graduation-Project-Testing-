package Automation_Project.Automation_Graduation_Project;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.testng.Assert;

public class RegisterTests_negativeScenario extends TestBase {

    RegisterPage registerPage;

    @BeforeMethod
    public void setup() {
        registerPage = new RegisterPage(driver);
    }

    @Test(priority = 1)
    public void testRegisterWithExistingEmail() throws InterruptedException {
        // Navigate to Signup/Login page
        driver.findElement(By.xpath("//a[contains(text(),'Signup / Login')]")).click();
        Thread.sleep(1000);

        // Assert we are on the correct page
        Assert.assertTrue(registerPage.newUserMessage.isDisplayed());

        // Use email that was already registered manually before
        registerPage.startRegistration("TestUser", "Shehabbadran07@gmail.com");
        Thread.sleep(1000);

        // Verify error message
        Assert.assertEquals(registerPage.failedMessage.getText(), "Email Address already exist!");
    }

    @Test(priority = 2)
    public void testRegisterWithEmptyFields() throws InterruptedException {
        driver.findElement(By.xpath("//a[contains(text(),'Signup / Login')]")).click();
        Thread.sleep(000);

        registerPage.startRegistration("", "");
        Thread.sleep(1000);

        // Still on the same page means validation worked
        Assert.assertTrue(registerPage.newUserMessage.isDisplayed(), "Form was submitted with empty fields!");
    }

    @Test(priority = 3)
    public void testRegisterWithInvalidEmail() throws InterruptedException {
        driver.findElement(By.xpath("//a[contains(text(),'Signup / Login')]")).click();
        Thread.sleep(0000);

        registerPage.startRegistration("InvalidEmailUser", "invalidemail"); // No @
        Thread.sleep(000);

        // Still on the same page means invalid email was blocked
        Assert.assertTrue(registerPage.newUserMessage.isDisplayed(), "Invalid email was not accepted!");
    }
}

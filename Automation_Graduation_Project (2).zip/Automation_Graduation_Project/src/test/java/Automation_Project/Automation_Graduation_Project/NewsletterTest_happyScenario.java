package Automation_Project.Automation_Graduation_Project;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.Assert;
import org.openqa.selenium.JavascriptExecutor;

public class NewsletterTest_happyScenario extends TestBase {

    NewsletterPage newsletterPage;

    @BeforeMethod
    public void setup() {
        newsletterPage = new NewsletterPage(driver);
    }

    @Test
    public void testSuccessfulSubscription() throws InterruptedException {
        // Scroll to footer
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
        Thread.sleep(1000);

        // Enter valid email and subscribe
        newsletterPage.enterEmail("shehabbadran07@gmail.com");
        newsletterPage.clickSubscribe();
        Thread.sleep(1000);

        // Assert success message
        String message = newsletterPage.getSubscriptionAlertText().trim().toLowerCase();
        System.out.println("Newsletter alert message: " + message);
        Assert.assertTrue(message.contains("successfully subscribed"), "Expected  success message found!");
    }
}
